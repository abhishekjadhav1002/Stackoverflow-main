import React from 'react'

const Failure = () => {
  return (
    <div><br /> <br /><br />Failure</div>
  )
}

export default Failure